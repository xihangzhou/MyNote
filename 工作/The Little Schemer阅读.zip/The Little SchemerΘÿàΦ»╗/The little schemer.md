# The Little Schemer阅读笔记

## 1. Toys

第一章就是理解一些定义的语法：

1. atom

* atom是不以(或者)开头的字符串
* 用空格间隔两个atom



2. list

* 理解为数组，成员可以是别的数组或是atom
* ()为空数组



3. S-expression

* a一个tom或者是一个list也是一个S-expression,可以理解为符合表达规则的表达式



4. car

* car of  l 或者 (car l) 返回一个list，即l，的第一个元素
* 返回值是一个S-expression
* 不能返回空list的car
* 不能返回atom的car



5. cdr

* cdr of l 或者(cur l)返回一个**非空**list，即l，的除了第一个元素的剩余元素
* 返回值是一个list

* 不能返回atom的cdr



6. con

* (cons a l) 表示把a加到list l 的首部，a可以是atom或者list
* 即a可以是任何S-expression



7. null

* (null? l) 返回一个l即list是否是空list



8. (atom? s)

* 返回s是否是一个atom



9. Eq

* （eq ? a b）意思为a和b是否相等
* 返回值为bool
* a和b都必须是不为数字的atom

## 2. Do it again

1. lat

* 由atom组成的list,可以为空
* (lat? l) 意思为l是否为lat

2. 

